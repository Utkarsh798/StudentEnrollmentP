package com.example.EnrollmentNew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrollmentNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
